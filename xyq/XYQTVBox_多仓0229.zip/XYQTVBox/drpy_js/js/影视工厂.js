var rule = Object.assign(muban.首图,{
title:'影视工厂',
host:'https://www.ysgc.cc',
});